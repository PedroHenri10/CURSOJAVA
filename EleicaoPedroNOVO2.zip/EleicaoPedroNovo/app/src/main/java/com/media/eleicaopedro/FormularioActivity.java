package com.media.eleicaopedro;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

public class FormularioActivity extends AppCompatActivity {

    EditText edtNome, edtTelefone;
    Button btnFinalizar;

    DatabaseHelper db;

    String[] cidades = {
            "São Paulo", "Rio de Janeiro", "Belo Horizonte", "Brasília", "Salvador",
            "Fortaleza", "Curitiba", "Recife", "Porto Alegre", "Manaus",
            "Belém", "Goiânia", "Florianópolis", "São Luís", "Maceió",
            "Natal", "Campo Grande", "Teresina", "João Pessoa", "Aracaju",
            "Cuiabá", "Porto Velho", "Boa Vista", "Rio Branco", "Macapá",
            "Palmas", "Vitória",
            "Santana de Parnaíba", "Osasco", "Carapicuíba", "Itapevi",
            "Jandira", "Barueri", "Cotia", "Santos", "Guarulhos",
            "Campinas", "São Bernardo do Campo", "Santo André",
            "Sorocaba", "Ribeirão Preto", "São José dos Campos"
    };

    public String getCidadeAleatoria() {
        java.util.Random random = new java.util.Random();
        int index = random.nextInt(cidades.length);
        return cidades[index];
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario);

        edtNome = findViewById(R.id.edtNome);
        edtTelefone = findViewById(R.id.edtTelefone);
        btnFinalizar = findViewById(R.id.btnFinalizar);

        db = new DatabaseHelper(this);

        btnFinalizar.setOnClickListener(v -> {

            String nome = edtNome.getText().toString();
            String telefone = edtTelefone.getText().toString();

            if (nome.isEmpty() || telefone.isEmpty()) {
                Toast.makeText(this, "Preencha tudo", Toast.LENGTH_SHORT).show();
                return;
            }

            String candidato = getIntent().getStringExtra("candidato");

            String data = new java.text.SimpleDateFormat("dd/MM/yyyy").format(new java.util.Date());
            String hora = new java.text.SimpleDateFormat("HH:mm:ss").format(new java.util.Date());

            String cidade = getCidadeAleatoria();

            db.inserir(nome, telefone, candidato, cidade, data, hora);

            Toast.makeText(this, "Salvo!", Toast.LENGTH_SHORT).show();

            Intent i = new Intent(this, MenuEntrevistadorActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);
            finish();
        });
    }
}