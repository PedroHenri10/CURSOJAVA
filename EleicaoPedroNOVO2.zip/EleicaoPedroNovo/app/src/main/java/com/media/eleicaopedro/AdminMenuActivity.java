package com.media.eleicaopedro;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.TextView;

public class AdminMenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_menu);

        DatabaseHelper db = new DatabaseHelper(this);

        TextView txtTotal = findViewById(R.id.txtTotal);

        int total = db.total();

        txtTotal.setText("Quantidade de pessoas entrevistadas: " + total);

        findViewById(R.id.btnEleitores).setOnClickListener(v ->
                startActivity(new Intent(this, AdminEleitoresActivity.class)));

        findViewById(R.id.btnResultados).setOnClickListener(v ->
                startActivity(new Intent(this, AdminResultadoActivity.class)));

        findViewById(R.id.btnLogout).setOnClickListener(v -> {
            Intent i = new Intent(this, Activity_login.class);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            finish();
        });
    }
}