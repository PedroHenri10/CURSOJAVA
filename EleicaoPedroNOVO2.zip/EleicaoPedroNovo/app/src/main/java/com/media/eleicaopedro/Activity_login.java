package com.media.eleicaopedro;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

public class Activity_login extends AppCompatActivity {

    private static final String ADMIN_USER = "pesquisadocabodaciolo";
    private static final String ADMIN_PASS = "vasco";

    private static final String USER = "leonKennedy";
    private static final String PASS = "123senha";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        EditText edtUser = findViewById(R.id.edtUser);
        EditText edtSenha = findViewById(R.id.edtSenha);
        Button btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(v -> {
            String user = edtUser.getText().toString().trim();
            String senha = edtSenha.getText().toString().trim();

            if (user.equals(ADMIN_USER) && senha.equals(ADMIN_PASS)) {
                startActivity(new Intent(this, AdminMenuActivity.class));
                finish();
            }
            else if (user.equals(USER) && senha.equals(PASS)) {
                startActivity(new Intent(this, MenuEntrevistadorActivity.class));
                finish();
            }
            else {
                Toast.makeText(this, "Login inválido", Toast.LENGTH_SHORT).show();
            }
        });
    }
}