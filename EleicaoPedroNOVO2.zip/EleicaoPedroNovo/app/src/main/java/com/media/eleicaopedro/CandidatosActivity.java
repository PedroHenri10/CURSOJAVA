package com.media.eleicaopedro;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

public class CandidatosActivity extends AppCompatActivity {

    private ImageView imgCandidato;
    private Button btnProximo;
    private RadioGroup radioGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_candidatos);

        imgCandidato = findViewById(R.id.imgCandidato);
        btnProximo = findViewById(R.id.btnProximo);
        radioGroup = findViewById(R.id.radioGroupCandidatos);

        imgCandidato.setImageResource(R.mipmap.ic_launcher);

        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            RadioButton rb = findViewById(checkedId);
            if (rb != null) {
                String nome = rb.getText().toString();

                switch (nome) {
                    case "Dua Lipa":
                        imgCandidato.setImageResource(R.drawable.dua);
                        break;
                    case "Amanda Nunes":
                        imgCandidato.setImageResource(R.drawable.amanda);
                        break;
                    case "Lionel Messi":
                        imgCandidato.setImageResource(R.drawable.messi);
                        break;
                    case "Caça Rato":
                        imgCandidato.setImageResource(R.drawable.cacarato);
                        break;
                    case "Snoop Dogg":
                        imgCandidato.setImageResource(R.drawable.snoop);
                        break;
                    default:
                        imgCandidato.setImageResource(R.mipmap.ic_launcher);
                        break;
                }
            }
        });

        btnProximo.setOnClickListener(v -> {

            int idSelecionado = radioGroup.getCheckedRadioButtonId();

            if (idSelecionado == -1) {
                Toast.makeText(this, "Escolha um candidato", Toast.LENGTH_SHORT).show();
                return;
            }

            RadioButton rb = findViewById(idSelecionado);
            String candidato = rb.getText().toString();

            Intent i = new Intent(this, ProblemasActivity.class);
            i.putExtra("candidato", candidato);

            startActivity(i);
        });
    }
}