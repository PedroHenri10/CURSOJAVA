package com.media.eleicaopedro;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

public class ProblemasActivity extends AppCompatActivity {

    CheckBox cbSaude, cbEducacao, cbSeguranca, cbEmprego, cbMeio;
    CheckBox cbTransporte, cbEconomia, cbSegurancaPublica, cbMoradia, cbCorrupcao;

    Button btnProximo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_problemas);

        cbSaude = findViewById(R.id.cbSaude);
        cbEducacao = findViewById(R.id.cbEducacao);
        cbSeguranca = findViewById(R.id.cbSeguranca);
        cbEmprego = findViewById(R.id.cbEmprego);
        cbMeio = findViewById(R.id.cbMeioAmbiente);
        cbTransporte = findViewById(R.id.cbTransporte);
        cbEconomia = findViewById(R.id.cbEconomia);
        cbSegurancaPublica = findViewById(R.id.cbSegurancaPublica);
        cbMoradia = findViewById(R.id.cbMoradia);
        cbCorrupcao = findViewById(R.id.cbCorrupcao);

        btnProximo = findViewById(R.id.btnProximo);

        btnProximo.setOnClickListener(v -> {

            int selecionados = 0;

            if (cbSaude.isChecked()) selecionados++;
            if (cbEducacao.isChecked()) selecionados++;
            if (cbSeguranca.isChecked()) selecionados++;
            if (cbEmprego.isChecked()) selecionados++;
            if (cbMeio.isChecked()) selecionados++;
            if (cbTransporte.isChecked()) selecionados++;
            if (cbEconomia.isChecked()) selecionados++;
            if (cbSegurancaPublica.isChecked()) selecionados++;
            if (cbMoradia.isChecked()) selecionados++;
            if (cbCorrupcao.isChecked()) selecionados++;

            if (selecionados > 3) {
                Toast.makeText(this, "Escolha no máximo 3 opções", Toast.LENGTH_SHORT).show();
                return;
            }

            if (selecionados == 0) {
                Toast.makeText(this, "Selecione pelo menos 1 opção", Toast.LENGTH_SHORT).show();
                return;
            }

            StringBuilder problemas = new StringBuilder();

            if (cbSaude.isChecked()) problemas.append("Saúde ");
            if (cbEducacao.isChecked()) problemas.append("Educação ");
            if (cbSeguranca.isChecked()) problemas.append("Segurança ");
            if (cbEmprego.isChecked()) problemas.append("Emprego ");
            if (cbMeio.isChecked()) problemas.append("Meio Ambiente ");
            if (cbTransporte.isChecked()) problemas.append("Transporte ");
            if (cbEconomia.isChecked()) problemas.append("Economia ");
            if (cbSegurancaPublica.isChecked()) problemas.append("Segurança Pública ");
            if (cbMoradia.isChecked()) problemas.append("Moradia ");
            if (cbCorrupcao.isChecked()) problemas.append("Corrupção ");

            String candidato = getIntent().getStringExtra("candidato");

            Intent i = new Intent(this, FormularioActivity.class);
            i.putExtra("problemas", problemas.toString().trim());
            i.putExtra("candidato", candidato);

            startActivity(i);
        });
    }
}