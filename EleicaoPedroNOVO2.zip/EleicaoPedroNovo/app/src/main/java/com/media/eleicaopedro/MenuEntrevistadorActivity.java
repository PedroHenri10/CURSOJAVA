package com.media.eleicaopedro;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MenuEntrevistadorActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_entrevistador);

        findViewById(R.id.btnPlanos).setOnClickListener(v ->
                startActivity(new Intent(this, IdeiasActivity.class)));

        findViewById(R.id.btnEstimulado).setOnClickListener(v ->
                startActivity(new Intent(this, CandidatosActivity.class)));

        findViewById(R.id.btnEspontanea).setOnClickListener(v ->
                startActivity(new Intent(this, FormularioEspontaneoActivity.class)));

        findViewById(R.id.btnLogout).setOnClickListener(v -> {
            Intent i = new Intent(this, Activity_login.class);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            finish();
        });
    }
}