package com.media.eleicaopedro;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class AdminEleitoresActivity extends AppCompatActivity {

    ListView listView;
    Button btnVoltar;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_eleitores);

        listView = findViewById(R.id.listEleitores);
        btnVoltar = findViewById(R.id.btnVoltar);
        db = new DatabaseHelper(this);

        List<String> lista = db.listarTodos();

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this,
                android.R.layout.simple_list_item_1,
                lista
        ) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView text = view.findViewById(android.R.id.text1);
                text.setTextColor(Color.WHITE);
                return view;
            }
        };

        listView.setAdapter(adapter);

        btnVoltar.setOnClickListener(v -> {
            Intent intent = new Intent(AdminEleitoresActivity.this, AdminMenuActivity.class);
            startActivity(intent);
            finish();
        });
    }
}