package com.media.eleicaopedro;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.*;
import com.github.mikephil.charting.formatter.PercentFormatter;

import java.util.*;

public class AdminResultadoActivity extends AppCompatActivity {

    PieChart chart;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_resultado);

        chart = findViewById(R.id.chart);
        db = new DatabaseHelper(this);

        Button btnVoltar = findViewById(R.id.btnVoltarResultado);
        btnVoltar.setOnClickListener(v -> finish());

        configurarGrafico();
        carregarDados();
    }

    private void configurarGrafico() {
        chart.setUsePercentValues(true);
        chart.getDescription().setEnabled(false);
        chart.setExtraOffsets(5, 10, 5, 10);

        chart.setDrawHoleEnabled(true);
        chart.setHoleColor(Color.TRANSPARENT);
        chart.setHoleRadius(50f);
        chart.setTransparentCircleRadius(55f);

        chart.setEntryLabelColor(Color.WHITE);
        chart.setEntryLabelTextSize(14f);
        chart.setEntryLabelTypeface(Typeface.DEFAULT_BOLD);

        Legend legend = chart.getLegend();
        legend.setTextColor(Color.WHITE);
        legend.setTextSize(12f);
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);
        legend.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        legend.setDrawInside(false);

        chart.animateY(1200);
    }

    private void carregarDados() {

        Map<String, Integer> dados = db.contagemVotos();

        List<String> oficiais = Arrays.asList(
                "Dua Lipa",
                "Amanda Nunes",
                "Lionel Messi",
                "Caça Rato",
                "Snoop Dogg"
        );

        int brancoNulo = 0;
        int outros = 0;

        Map<String, Integer> filtrados = new LinkedHashMap<>();

        for (Map.Entry<String, Integer> e : dados.entrySet()) {

            String nome = e.getKey();
            int qtd = e.getValue();

            if (nome.equalsIgnoreCase("Branco") || nome.equalsIgnoreCase("Nulo")) {
                brancoNulo += qtd;

            } else if (oficiais.contains(nome)) {
                filtrados.put(nome, qtd);

            } else {
                outros += qtd;
            }
        }

        ArrayList<PieEntry> entries = new ArrayList<>();

        for (Map.Entry<String, Integer> e : filtrados.entrySet()) {
            entries.add(new PieEntry(e.getValue(), e.getKey()));
        }

        if (brancoNulo > 0) {
            entries.add(new PieEntry(brancoNulo, "Branco/Nulo"));
        }

        if (outros > 0) {
            entries.add(new PieEntry(outros, "Outros"));
        }

        PieDataSet dataSet = new PieDataSet(entries, "");

        ArrayList<Integer> colors = new ArrayList<>();
        colors.add(Color.parseColor("#39FF14"));
        colors.add(Color.parseColor("#FF007F"));
        colors.add(Color.parseColor("#00FFFF"));
        colors.add(Color.parseColor("#FFFF00"));
        colors.add(Color.parseColor("#FF9800"));
        colors.add(Color.parseColor("#9E9E9E"));

        dataSet.setColors(colors);
        dataSet.setSliceSpace(3f);
        dataSet.setValueTextColor(Color.BLACK);
        dataSet.setValueTextSize(14f);
        dataSet.setValueTypeface(Typeface.DEFAULT_BOLD);

        PieData data = new PieData(dataSet);
        data.setValueFormatter(new PercentFormatter(chart));

        chart.setData(data);
        chart.invalidate();
    }
}