package com.media.eleicaopedro;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class FormularioEspontaneoActivity extends AppCompatActivity {

    EditText edtNome, edtVoto;
    EditText edtTelefone;
    Button btnSalvar;

    DatabaseHelper db;

    String[] cidades = {
            "São Paulo", "Rio de Janeiro", "Belo Horizonte", "Brasília", "Salvador",
            "Fortaleza", "Curitiba", "Recife", "Porto Alegre", "Manaus",
            "Belém", "Goiânia", "Florianópolis", "São Luís", "Maceió",
            "Natal", "Campo Grande", "Teresina", "João Pessoa", "Aracaju",
            "Cuiabá", "Porto Velho", "Boa Vista", "Rio Branco", "Macapá",
            "Palmas", "Vitória",
            "Santana de Parnaíba", "Osasco", "Carapicuíba", "Itapevi",
            "Jandira", "Barueri", "Cotia", "Santos", "Guarulhos",
            "Campinas", "São Bernardo do Campo", "Santo André",
            "Sorocaba", "Ribeirão Preto", "São José dos Campos"
    };

    public String getCidadeAleatoria() {
        java.util.Random random = new java.util.Random();
        int index = random.nextInt(cidades.length);
        return cidades[index];
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario_espontaneo);

        edtNome = findViewById(R.id.edtNome);
        edtVoto = findViewById(R.id.edtVoto);
        edtTelefone = findViewById(R.id.edtTelefone);
        btnSalvar = findViewById(R.id.btnSalvar);

        db = new DatabaseHelper(this);

        btnSalvar.setOnClickListener(v -> {

            String nome = edtNome.getText().toString();
            String voto = edtVoto.getText().toString();

            if (nome.isEmpty() || voto.isEmpty()) {
                Toast.makeText(this, "Preencha tudo", Toast.LENGTH_SHORT).show();
                return;
            }

            String telefone = edtTelefone.getText().toString();

            String data = new java.text.SimpleDateFormat("dd/MM/yyyy").format(new java.util.Date());
            String hora = new java.text.SimpleDateFormat("HH:mm:ss").format(new java.util.Date());

            String cidade = getCidadeAleatoria();

            db.inserir(nome, telefone, voto, cidade, data, hora);

            Toast.makeText(this, "Salvo!", Toast.LENGTH_SHORT).show();

            finish();
        });
    }
}