public class Eleitor {

    private int id;
    private String nome;
    private String telefone;
    private String voto;
    private String cidade;
    private String data;
    private String hora;

    public Eleitor(int id, String nome, String telefone, String voto,
                   String cidade, String data, String hora) {
        this.id = id;
        this.nome = nome;
        this.telefone = telefone;
        this.voto = voto;
        this.cidade = cidade;
        this.data = data;
        this.hora = hora;
    }

    public String getNome() { return nome; }
    public String getTelefone() { return telefone; }
    public String getVoto() { return voto; }
    public String getCidade() { return cidade; }
    public String getData() { return data; }
    public String getHora() { return hora; }

    @Override
    public String toString() {
        return nome + " | " + telefone +
                "\nVoto: " + voto +
                "\nCidade: " + cidade +
                "\nData: " + data + " " + hora;
    }
}