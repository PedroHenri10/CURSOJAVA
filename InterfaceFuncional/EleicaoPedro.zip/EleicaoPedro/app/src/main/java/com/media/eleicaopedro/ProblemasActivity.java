package com.media.eleicaopedro;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

public class ProblemasActivity extends AppCompatActivity {

    CheckBox cbSaude, cbEducacao, cbSeguranca, cbEmprego, cbMeio;
    Button btnProximo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_problemas);

        cbSaude = findViewById(R.id.cbSaude);
        cbEducacao = findViewById(R.id.cbEducacao);
        cbSeguranca = findViewById(R.id.cbSeguranca);
        cbEmprego = findViewById(R.id.cbEmprego);
        cbMeio = findViewById(R.id.cbMeioAmbiente);
        btnProximo = findViewById(R.id.btnProximo);

        btnProximo.setOnClickListener(v -> {

            String problemas = "";

            if (cbSaude.isChecked()) problemas += "Saúde ";
            if (cbEducacao.isChecked()) problemas += "Educação ";
            if (cbSeguranca.isChecked()) problemas += "Segurança ";
            if (cbEmprego.isChecked()) problemas += "Emprego ";
            if (cbMeio.isChecked()) problemas += "Meio Ambiente ";

            String candidato = getIntent().getStringExtra("candidato");

            Intent i = new Intent(this, FormularioActivity.class);
            i.putExtra("problemas", problemas);
            i.putExtra("candidato", candidato);
            startActivity(i);
        });
    }
}