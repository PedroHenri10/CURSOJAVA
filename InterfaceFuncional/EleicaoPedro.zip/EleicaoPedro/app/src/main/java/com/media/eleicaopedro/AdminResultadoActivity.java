package com.media.eleicaopedro;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.*;

import java.util.*;

public class AdminResultadoActivity extends AppCompatActivity {

    PieChart chart;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_resultado);

        chart = findViewById(R.id.chart);
        db = new DatabaseHelper(this);

        Map<String, Integer> dados = db.contagemVotos();

        ArrayList<PieEntry> entries = new ArrayList<>();

        for (String nome : dados.keySet()) {
            entries.add(new PieEntry(dados.get(nome), nome));
        }

        PieDataSet dataSet = new PieDataSet(entries, "Votos");
        PieData data = new PieData(dataSet);

        chart.setData(data);
        chart.setUsePercentValues(true);
        chart.invalidate();
    }
}