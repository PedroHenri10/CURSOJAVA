class Supermercado {
	public static void main(String[] args){
		float brocolis = 5.6f;
		float pera = 4.2f;
		
		float somaMercado = brocolis + pera;
		
		 System.out.printf("Total soma: %.2f%n", somaMercado);	
	}
}