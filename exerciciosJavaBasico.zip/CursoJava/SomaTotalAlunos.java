class SomaTotalAlunos{
	public static void main(String[] args){
		int salaCobol = 23;
		int salaJavaScript = 37;
		
		int totalAlunos = salaCobol + salaJavaScript;
		
		System.out.println("Total de alunos(sala de cobol + sala de java): "+ totalAlunos);
	}
}