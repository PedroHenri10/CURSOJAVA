class ParOuImpar{
	public static void main(String[] args){
		int valor1 = 40;
		int valor2 = 7;
		
		
		if(valor1 % 2 == 0){
			System.out.println("valor: "+ valor1 + " eh par!");		
		}else{
			System.out.println("valor: "+ valor1 + " eh impar!");		
		}
		
		if(valor2 % 2 == 0){
			System.out.println("valor: "+ valor2 + " eh par!");		
		}else{
			System.out.println("valor: "+ valor2 + " eh impar!");		
		}
		
	}
}