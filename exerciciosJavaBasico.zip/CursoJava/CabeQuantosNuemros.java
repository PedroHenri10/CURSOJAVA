class CabeQuantosNuemros{
	public static void main(String[] args){
		int valor1 = 23;
		int valor2 = 2;
		int cabe = valor1/valor2;
		
		System.out.println("Quantas vezes cabe? "+ cabe + " vezes");
	}
}