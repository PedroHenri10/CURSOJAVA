class TamanhoString{
	public static void main(String[] args){
		String texto1 = "Vasco";
		int tamanho = texto1.length();
		
	
			System.out.println("O tamanho dessa String é de " + tamanho+ " caracteres");
	}
}