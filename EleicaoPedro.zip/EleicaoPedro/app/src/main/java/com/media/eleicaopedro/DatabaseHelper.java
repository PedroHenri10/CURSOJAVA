package com.media.eleicaopedro;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "eleicao.db";
    private static final int DB_VERSION = 2;

    private static final String TABLE = "votos";

    public DatabaseHelper(Context ctx) {
        super(ctx, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE + " ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "nome TEXT, "
                + "telefone TEXT, "
                + "candidato TEXT, "
                + "cidade TEXT, "
                + "data TEXT, "
                + "hora TEXT"
                + ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE);
        onCreate(db);
    }

    public long inserir(String nome, String telefone, String candidato,
                        String cidade, String data, String hora) {

        ContentValues cv = new ContentValues();
        cv.put("nome", nome);
        cv.put("telefone", telefone);
        cv.put("candidato", candidato);
        cv.put("cidade", cidade);
        cv.put("data", data);
        cv.put("hora", hora);

        return getWritableDatabase().insert(TABLE, null, cv);
    }

    public List<String> listarTodos() {
        List<String> lista = new ArrayList<>();

        Cursor c = getReadableDatabase()
                .rawQuery("SELECT * FROM " + TABLE + " ORDER BY id DESC", null);

        while (c.moveToNext()) {
            String item =
                    "Nome: " + c.getString(1) +
                            "\nTelefone: " + c.getString(2) +
                            "\nVoto: " + c.getString(3) +
                            "\nCidade: " + c.getString(4) +
                            "\nData: " + c.getString(5) +
                            "\nHora: " + c.getString(6);

            lista.add(item);
        }

        c.close();
        return lista;
    }

    public Map<String, Integer> contagemVotos() {
        Map<String, Integer> mapa = new HashMap<>();

        Cursor c = getReadableDatabase().rawQuery(
                "SELECT candidato, COUNT(*) FROM votos GROUP BY candidato",
                null
        );

        while (c.moveToNext()) {
            mapa.put(c.getString(0), c.getInt(1));
        }

        c.close();
        return mapa;
    }
}