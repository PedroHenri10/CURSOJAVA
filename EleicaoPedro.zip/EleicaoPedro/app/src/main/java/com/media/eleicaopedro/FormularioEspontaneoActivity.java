package com.media.eleicaopedro;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class FormularioEspontaneoActivity extends AppCompatActivity {

    EditText edtNome, edtVoto;
    CheckBox cbEleitor;
    Button btnSalvar;

    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario_espontaneo);

        edtNome = findViewById(R.id.edtNome);
        edtVoto = findViewById(R.id.edtVoto);
        cbEleitor = findViewById(R.id.cbEleitor);
        btnSalvar = findViewById(R.id.btnSalvar);

        db = new DatabaseHelper(this);

        btnSalvar.setOnClickListener(v -> {

            String nome = edtNome.getText().toString();
            String voto = edtVoto.getText().toString();

            if (nome.isEmpty() || voto.isEmpty()) {
                Toast.makeText(this, "Preencha tudo", Toast.LENGTH_SHORT).show();
                return;
            }

            String telefone = "000000000";

            String data = new java.text.SimpleDateFormat("dd/MM/yyyy").format(new java.util.Date());
            String hora = new java.text.SimpleDateFormat("HH:mm:ss").format(new java.util.Date());

            String cidade = "São Paulo";

            db.inserir(nome, telefone, voto, cidade, data, hora);

            Toast.makeText(this, "Salvo!", Toast.LENGTH_SHORT).show();

            finish();
        });
    }
}