/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulasobrecarga;

/**
 *
 * @author 2830482411031
 */
public class Desenho {

    public static void main(String[] args) {
        Figura x = new Figura(500);
        Figura y = new Figura(10,70);
        Figura z = new Figura(10,70, 50, 100);
        Figura q = new Figura(10,70, 50);
        
        x.exibirFigura();
        y.exibirFigura();
        z.exibirFigura();
        q.exibirFigura();
        
        Menu m = new Menu();
        //x.exibirFigura(500);
        //y.exibirFigura("www");
        //q.exibirFigura(0, 0, 0);
        //z.exibirFigura(1,2,3,4);
    }
}
