/*|
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulasobrecarga;

import javax.swing.JOptionPane;

/**
 *
 * @author 2830482411031
 */
public class Menu {
    int opc;
    String msg;
    Figura figura;
    boolean flag;

    
    public Menu(){
        flag = false;
        
        msg = "| - Ponto\n2 - Linha\n3 - Triangulo\n4 - Retangulo";
        msg = msg + "\n5 - Finalizar o programa";
        
        while(true){
            opc = Integer.parseInt(JOptionPane.showInputDialog(msg));
        
        switch(opc){
            case 1: int a = Integer.parseInt(JOptionPane.showInputDialog("Digite o valor do ponto"));
                figura = new Figura(a);
                break;
            case 2: int x,y;
                x = Integer.parseInt(JOptionPane.showInputDialog("Digite o valor incial da linha"));
                y = Integer.parseInt(JOptionPane.showInputDialog("Digite o valor final da linha"));
                figura = new Figura(x,y);
                break;
            case 3: int t,e,q;
                t = Integer.parseInt(JOptionPane.showInputDialog("Digite o valor incial do triangulo"));
                e = Integer.parseInt(JOptionPane.showInputDialog("Digite o valor inicial da base do triangulo"));
                q = Integer.parseInt(JOptionPane.showInputDialog("Digite o valor final da base do triangulo"));
                figura = new Figura(t,e,q);
                break;
            case 4: int w,z,c,p;
                w = Integer.parseInt(JOptionPane.showInputDialog("Digite o valor incial do retangulo"));
                z = Integer.parseInt(JOptionPane.showInputDialog("Digite o valor inicial da base do retangulo"));
                c = Integer.parseInt(JOptionPane.showInputDialog("Digite o valor final da base do retangulo"));
                p = Integer.parseInt(JOptionPane.showInputDialog("Digite o valor final do triangulo"));
                figura = new Figura(w,z,c,p);
                break;
            case 5: System.exit(0);
            
            default: flag = true;
            System.out.println("Opcao Invalida!");
            }//fim do switch
        if(flag != true)
            figura.exibirFigura();
        }//fim do while
    }//fim do constructor
}//fim da classe
